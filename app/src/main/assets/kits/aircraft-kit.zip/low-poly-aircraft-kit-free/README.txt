Low-Poly Aircraft Kit Free
==========================
8 low-poly props: trainer plane, light helicopter, runway, runway threshold,
grass tile, small hangar, windsock and traffic cone. Made and licensed by
heyheythere.

GLB and FBX carry the clips (the trainer's propeller turning and its ailerons,
elevator and rudder moving, the helicopter's rotors spinning, the hangar's
roller door rising, the windsock blowing). OBJ is static; the .blend source,
colour atlas, PNG icons and props.json are included. This folder is a Godot
4.3+ project with a gallery. Copy addons/low_poly_aircraft_kit/ into your
project; the full pack replaces it in the same folder.

Metre scale. In Blender, +Z is up and the aircraft face -Y; in Godot, +Y is up
and they face +Z. An aircraft's origin is on the ground under it, its wheels
or skids at 0. Moving parts are named after it, their pivots at the hub or
hinge: trainer_propeller, trainer_aileron_left and _right (its left is +X),
trainer_elevator, trainer_rudder, helicopter_rotor_main, helicopter_rotor_tail.
The trainer's "controls" clip (3 s) swings its controls one way at 0.75 s and
the other at 2.25 s. Tiles are 20 x 20 m, top at 0, origin in the middle; the
runway runs along Y and the threshold has it on to +Y.

Props use box colliders. Supply your own flight; the full kit's demo flies
them from its airfield.

CC BY 4.0: commercial use, modification and redistribution allowed with credit:
Low-Poly Aircraft Kit Free by heyheythere - https://heyheythere.itch.io/low-poly-aircraft-kit-free - CC BY 4.0
See LICENSE.txt for the full terms.
