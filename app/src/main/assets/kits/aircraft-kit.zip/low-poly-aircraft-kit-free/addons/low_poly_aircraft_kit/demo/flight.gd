extends "res://addons/low_poly_aircraft_kit/demo/gallery.gd"
## The kit's gallery in daylight, and its airfield to fly from: F (or Fly) puts you at the
## runway's end in one of the aircraft, the layout's `traffic` takes off round the field, and the
## layout's `gates`, pairs of pylons, are a course to fly through in order, timed from the wheels
## leaving the runway. W and S set the throttle (a helicopter's collective), the arrows are the
## stick (Down pulls the nose up), A and D the rudder, G the gear; C changes the aircraft, R puts it
## back on the runway, Esc leaves. The glider starts aloft, as if just off its tow.
##
## The flying is arcade: a plane goes where its nose points at its airspeed, banking turns it, and
## below its stall speed it sinks and drops its nose. Its parts are posed from its clips, each
## part from the clip that moves it: the spin turns with the throttle, the controls follow the
## stick, the gear its lever, so they play at once.

const G := 9.8
## stall and top speed (m/s), thrust (m/s/s), roll and pitch rates (rad/s); a helicopter is "heli".
const HANDLING := {
	"trainer": [20.0, 55.0, 6.0, 1.6, 0.9], "sport_plane": [24.0, 72.0, 7.0, 2.2, 1.0],
	"biplane": [18.0, 50.0, 6.0, 2.0, 1.0], "warbird": [32.0, 120.0, 8.0, 2.4, 1.0],
	"seaplane": [20.0, 50.0, 5.0, 1.4, 0.8], "cargo_plane": [32.0, 95.0, 4.5, 0.9, 0.55],
	"airliner": [45.0, 140.0, 4.0, 0.8, 0.45], "business_jet": [40.0, 140.0, 5.0, 1.2, 0.6],
	"glider": [15.0, 45.0, 0.0, 1.4, 0.8],
}
const PLANE := [25.0, 70.0, 6.0, 1.5, 0.8]  # an aircraft not in HANDLING
const GATE_WIDTH := 18.0
const GATE_TOP := 22.0  # m: over the pylons' tops is round the gate
const GLIDER_START := 220.0  # m up

var flying := false
var autopilot := false  # flown round the course by itself: for the tests
var craft: Node3D
var craft_prop := {}
var craft_index := 0
var aircraft: Array  # the props that fly
var heli := false
var hand: Array  # stall, top, thrust, roll rate, pitch rate
var speed := 0.0  # a plane's, along its nose
var sink := 0.0  # a plane's, below its stall speed
var velocity := Vector3.ZERO  # a helicopter's
var throttle := 0.0
var on_ground := true
var gear_up := false
var gear := 0.0  # 0 down, 1 up
var rotor := 0.0  # a helicopter's rotor speed, 0 to 1
var spin := 0.0  # seconds into the spin clip
var crashed := 0.0  # seconds to the reset
var tracks := {}  # the flown craft's moving tracks by clip: "spin", "controls", "gear"
var stick := Vector3.ZERO  # pitch (nose up), roll (right), yaw (right), -1 to 1
var gates: Array = []  # {at, along}, Godot
var gate := 0
var ring := MeshInstance3D.new()  # round the next gate
var started := -1.0  # the course's clock, from leaving the ground
var clock := 0.0
var finished := -1.0
var best := INF
var traffic: Array = []  # {node, centre, radius, speed, angle, tracks}
var flight_hud := CanvasLayer.new()
var board := Label.new()
var call_out := Label.new()
var keys_help := Label.new()


func _ready() -> void:
	super._ready()
	aircraft = props.filter(func(p): return p["group"] == "aircraft")
	for g in level.get("gates", []):
		var a := deg_to_rad(g[2])
		gates.append({"at": _gd([g[0], g[1], 0]), "along": Vector3(sin(a), 0, -cos(a))})
	add_child(flight_hud)
	for l in [board, call_out, keys_help]:
		l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.08))
		l.add_theme_constant_override("outline_size", 6)
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		flight_hud.add_child(l)
	board.position = Vector2(20, 16)
	board.add_theme_font_size_override("font_size", 22)
	call_out.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	call_out.grow_horizontal = Control.GROW_DIRECTION_BOTH
	call_out.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	call_out.position.y -= 120
	call_out.add_theme_font_size_override("font_size", 44)
	keys_help.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	keys_help.position = Vector2(20, -40)
	keys_help.add_theme_font_size_override("font_size", 16)
	keys_help.text = "W/S throttle   arrows: stick   A/D rudder   G gear   C change   R reset   Esc out"
	flight_hud.hide()
	var torus := TorusMesh.new()
	torus.inner_radius = 7.4
	torus.outer_radius = 8.0
	torus.rings = 32
	ring.mesh = torus
	var glow := StandardMaterial3D.new()
	glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	glow.albedo_color = Color(1.0, 0.85, 0.1, 0.75)
	glow.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ring.material_override = glow
	ring.hide()
	world.add_child(ring)


## The gallery's backdrop in daylight colours.
func _stage() -> void:
	super._stage()
	env.background_color = Color(0.56, 0.66, 0.76)
	ground.material_override = _flat(Color(0.42, 0.45, 0.48))
	wall.material_override = _flat(Color(0.62, 0.68, 0.74))


## The level under a clear sky, in sunlight, on grass to the horizon.
func _dark(on: bool) -> void:
	super._dark(on)
	_out_of_doors(on)


## A set out of doors too.
func show_set(items: Array) -> void:
	super.show_set(items)
	_out_of_doors(true)


## Sky and grass in place of the gallery's backdrop, or the backdrop back.
func _out_of_doors(on: bool) -> void:
	(ground.mesh as PlaneMesh).size = Vector2.ONE * (6000.0 if on else 40.0)
	ground.position.y = -0.05 if on else -0.003  # under the tiles' tops
	ground.material_override = _flat(Color("5da34a") if on else Color(0.42, 0.45, 0.48))
	ground.visible = true
	if on:
		wall.hide()
		_sky()
	else:  # the gallery's sun
		sun.rotation_degrees = Vector3(-55, -30, 0)
		sun.light_color = Color(1.0, 0.9, 0.75)
		sun.light_energy = 1.0


func _sky() -> void:
	var mat := ProceduralSkyMaterial.new()
	mat.sky_top_color = Color(0.25, 0.47, 0.8)
	mat.sky_horizon_color = Color(0.72, 0.82, 0.9)
	mat.ground_horizon_color = Color(0.72, 0.82, 0.9)
	mat.ground_bottom_color = Color(0.45, 0.55, 0.45)
	env.sky = Sky.new()
	env.sky.sky_material = mat
	env.background_mode = Environment.BG_SKY
	env.ambient_light_color = Color(0.78, 0.84, 0.95)
	env.ambient_light_energy = 0.6
	env.fog_light_color = Color(0.72, 0.82, 0.9)
	env.fog_density = level.get("fog", 0.0025)
	env.fog_sky_affect = 0.0
	var light: Array = level.get("light", ["fff1d8", 1.3])
	sun.show()
	sun.light_color = Color(light[0])
	sun.light_energy = light[1]
	sun.rotation_degrees = Vector3(-48, 35, 0)
	sun.directional_shadow_max_distance = 200.0


func _ui() -> void:
	super._ui()
	if level.is_empty():
		return
	for b in ui.find_children("*", "Button", true, false):
		if b.text == "Walk":
			var f := _button(b.get_parent(), "Fly", fly.bind(true))
			b.get_parent().move_child(f, b.get_index() + 1)


## Into the air from the runway's end, or back out to the level's view.
func fly(on: bool) -> void:
	if on == flying or level.is_empty() or not level.has("takeoff"):
		return
	if walker:
		_off_foot()
	if not on:
		flying = false
		craft = null
		traffic = []
		ring.hide()
		flight_hud.hide()
		ui.visible = not still
		show_level()
		return
	show_level(false)
	flying = true
	cam.fov = 70
	for t in level.get("traffic", []):
		_take_off(t)
	_board(craft_index)
	ui.hide()
	flight_hud.show()


## A parked aircraft taken from where the layout put it (`at`) to fly round its circle.
func _take_off(t: Dictionary) -> void:
	var at := _gd([t["at"][0], t["at"][1], 0])
	var node: Node3D = null
	for n in shown.get_children():
		if n.has_meta("prop") and n.get_meta("prop")["name"] == t["prop"] and n.position.distance_to(at) < 3.0:
			node = n
	if not node:
		return
	for b in node.find_children("*", "StaticBody3D", true, false):
		b.free()
	traffic.append({"node": node, "centre": _gd(t["centre"]), "radius": t["radius"], "speed": t["speed"],
			"angle": randf() * TAU, "tracks": _moving(node)})


## The `index`th aircraft at the runway's end, engine idling (the glider aloft over it).
func _board(index: int) -> void:
	if craft:
		craft.queue_free()
	craft_index = posmod(index, aircraft.size())
	craft_prop = aircraft[craft_index]
	craft = load("%s/props/%s.tscn" % [dir, craft_prop["name"]]).instantiate()
	for b in craft.find_children("*", "StaticBody3D", true, false):
		b.free()
	shown.add_child(craft)
	tracks = _moving(craft)
	heli = craft_prop["anims"].any(func(a): return a["name"] == "spin") and craft_prop["parts"].any(func(p): return p["name"].ends_with("_rotor_main"))
	hand = HANDLING.get(craft_prop["name"], PLANE)
	var t: Array = level["takeoff"]
	craft.position = _gd([t[0], t[1], 0])
	craft.basis = Basis(Vector3.UP, deg_to_rad(t[2]))
	speed = 0.0
	sink = 0.0
	velocity = Vector3.ZERO
	throttle = 0.0
	rotor = 0.0
	on_ground = true
	gear_up = false
	gear = 0.0
	crashed = 0.0
	stick = Vector3.ZERO
	gate = 0
	started = -1.0
	finished = -1.0
	if not heli and hand[2] == 0.0:  # a glider, just off its tow
		craft.position.y = GLIDER_START
		speed = hand[0] * 1.6
		on_ground = false
	_pose(craft, tracks, 0.0)
	_ring()
	if heli:
		_say_out("%s
W climbs once the rotor is up to speed" % craft_prop["title"], 3.0)
	elif hand[2] > 0.0:
		_say_out("%s
W opens the throttle, Down lifts off at speed" % craft_prop["title"], 3.0)
	cam.position = craft.position - craft.basis.z * 30.0 + Vector3.UP * 8.0


## The tracks each clip moves on `model`'s parts: a clip holds the parts another one moves at rest,
## so a part is posed from the clip that moves it.
func _moving(model: Node3D) -> Dictionary:
	var out := {}
	var player := model.find_child("AnimationPlayer", true, false) as AnimationPlayer
	if not player:
		return out
	player.stop()
	var root := player.get_node(player.root_node)
	for clip in player.get_animation_list():
		var a := player.get_animation(clip)
		var moved: Array = []
		for t in a.get_track_count():
			var type := a.track_get_type(t)
			if type not in [Animation.TYPE_POSITION_3D, Animation.TYPE_ROTATION_3D, Animation.TYPE_SCALE_3D] or a.track_get_key_count(t) < 2:
				continue
			var first = a.track_get_key_value(t, 0)
			var still_part := true
			for k in range(1, a.track_get_key_count(t)):
				if not a.track_get_key_value(t, k).is_equal_approx(first):
					still_part = false
					break
			if not still_part:
				var node := root.get_node_or_null(NodePath(String(a.track_get_path(t)).get_slice(":", 0)))
				if node:
					moved.append({"anim": a, "track": t, "type": type, "node": node})
		out[String(clip)] = moved
	return out


## The flown aircraft's parts: the spin at its clip's `spin` seconds, the controls following the
## stick (the clip swings each one way at a quarter of its length, the other at three quarters),
## the gear at `gear` of its clip.
func _pose(model: Node3D, by: Dictionary, spun: float) -> void:
	for t in by.get("spin", []):
		_sample(t, fposmod(spun, t["anim"].length))
	for t in by.get("controls", []):
		var part: String = t["node"].name
		var f := -stick.y if part.contains("aileron") else stick.x if part.contains("elevator") else stick.z
		var length: float = t["anim"].length
		_sample(t, length * 0.25 * f if f >= 0.0 else length + length * 0.25 * f)
	for t in by.get("gear", []):
		_sample(t, t["anim"].length * gear)


func _sample(t: Dictionary, at: float) -> void:
	var a: Animation = t["anim"]
	match t["type"]:
		Animation.TYPE_ROTATION_3D:
			t["node"].quaternion = a.rotation_track_interpolate(t["track"], at)
		Animation.TYPE_POSITION_3D:
			t["node"].position = a.position_track_interpolate(t["track"], at)
		Animation.TYPE_SCALE_3D:
			t["node"].scale = a.scale_track_interpolate(t["track"], at)


func _physics_process(delta: float) -> void:
	if not flying:
		super._physics_process(delta)
		return
	clock += delta
	for t in traffic:
		_circle(t, delta)
	if crashed > 0.0:
		crashed -= delta
		if crashed <= 0.0:
			_board(craft_index)
		return
	if autopilot:
		_autopilot()
	else:
		_controls(delta)
	var before := craft.position
	if heli:
		_hover(delta)
	else:
		_fly(delta)
	if crashed > 0.0:
		return
	_hits(before)
	_gates(before)
	gear = move_toward(gear, 1.0 if gear_up else 0.0, delta / 2.5)
	spin += delta * (rotor if heli else (0.0 if hand[2] == 0.0 else 0.3 + 0.7 * throttle))
	_pose(craft, tracks, spin)


func _controls(delta: float) -> void:
	throttle = clampf(throttle + (_key(KEY_W, KEY_W) - _key(KEY_S, KEY_S)) * delta * 0.6, 0.0, 1.0)
	var want := Vector3(_key(KEY_DOWN, KEY_DOWN) - _key(KEY_UP, KEY_UP), _key(KEY_RIGHT, KEY_RIGHT) - _key(KEY_LEFT, KEY_LEFT),
			_key(KEY_D, KEY_D) - _key(KEY_A, KEY_A))
	stick = stick.move_toward(want, delta * 4.0)


## A plane: thrust against drag and the climb, flown where its nose points, turned by its bank;
## below the stall it sinks and its nose drops. On the ground it rolls level, steered by the
## rudder, until it lifts off at its stall speed with the stick back.
func _fly(delta: float) -> void:
	var stall: float = hand[0]
	var top: float = hand[1]
	var thrust: float = hand[2] * throttle
	var b := craft.basis.orthonormalized()
	var fwd := b.z
	var drag: float = (hand[2] if hand[2] > 0.0 else 4.0) / (top * top)
	speed += (thrust - drag * speed * speed - G * fwd.y - (2.0 if on_ground and throttle < 0.05 else 0.0)) * delta
	speed = maxf(speed, 0.0)
	var lift := clampf((speed - stall * 0.6) / (stall * 0.4), 0.0, 1.0)
	var authority := clampf(speed / stall, 0.0, 1.2)
	if on_ground:
		b = Basis(Vector3.UP, -stick.z * 0.7 * minf(speed / 8.0, 1.0) * delta) * Basis(Vector3.UP, atan2(fwd.x, fwd.z))
		craft.position += b.z * speed * delta
		craft.position.y = 0.0
		if speed >= stall and stick.x > 0.2:
			on_ground = false
			b = Basis(b.x, -0.08) * b
			if started < 0.0:
				started = clock
		craft.basis = b
		return
	b = Basis(b.z, stick.y * hand[3] * authority * delta) * b  # roll
	b = Basis(b.x, -stick.x * hand[4] * authority * delta) * b  # pitch
	b = Basis(b.y, -stick.z * 0.35 * authority * delta) * b  # yaw
	var bank := asin(clampf(b.x.y, -1.0, 1.0))  # right wing down: the left one (+X) up
	if absf(stick.y) < 0.1:  # it rights itself
		b = Basis(b.z, -bank * 0.5 * delta) * b
	b = Basis(Vector3.UP, -G * tan(clampf(bank, -1.2, 1.2)) / maxf(speed, 10.0) * lift * delta) * b
	if lift < 1.0:  # the stall: the nose drops
		b = Basis(b.x, (1.0 - lift) * 0.9 * delta) * b
	sink = move_toward(sink, (1.0 - lift) * 18.0, G * delta)
	craft.basis = b.orthonormalized()
	craft.position += craft.basis.z * speed * delta + Vector3.DOWN * sink * delta
	if craft.position.y <= 0.0:
		_touch(craft.basis.z.y * speed - sink, bank)


## Down on the ground: a landing if it comes down gently, wings level, nose not down, wheels out;
## a crash otherwise.
func _touch(vertical: float, bank: float) -> void:
	var fwd := craft.basis.z
	var wheels := not tracks.has("gear") or gear < 0.1
	if vertical > -5.0 and absf(bank) < 0.35 and fwd.y > -0.15 and wheels:
		on_ground = true
		sink = 0.0
		craft.position.y = 0.0
		craft.basis = Basis(Vector3.UP, atan2(fwd.x, fwd.z))
		if finished > 0.0:
			_say_out("LANDED", 3.0)
	else:
		_crash("WHEELS UP" if not wheels else "CRASHED")


## A helicopter: the collective (W, S) climbs and descends once its rotor is up to speed, the stick
## tilts it and the tilt carries it along, the rudder turns it.
func _hover(delta: float) -> void:
	rotor = move_toward(rotor, 1.0, delta / 3.0)
	var heading := atan2(craft.basis.z.x, craft.basis.z.z) - stick.z * 1.2 * delta
	var tilt := Vector2(-stick.x, stick.y) * 0.35 * (0.0 if on_ground else 1.0)
	var climb := (_key(KEY_W, KEY_W) - _key(KEY_S, KEY_S)) * 7.0 if not autopilot else throttle
	velocity.y = move_toward(velocity.y, climb if rotor > 0.9 else -2.0, 8.0 * delta)
	var flat := Basis(Vector3.UP, heading)
	velocity += (flat.z * tan(tilt.x) - flat.x * tan(tilt.y)) * G * delta
	velocity.x *= 1.0 - 0.3 * delta
	velocity.z *= 1.0 - 0.3 * delta
	var cur_tilt: Vector2 = craft.get_meta("tilt", Vector2.ZERO)
	cur_tilt = cur_tilt.move_toward(tilt, delta)
	craft.set_meta("tilt", cur_tilt)
	craft.basis = flat * Basis(Vector3.RIGHT, cur_tilt.x) * Basis(Vector3.BACK, cur_tilt.y)
	craft.position += velocity * delta
	if craft.position.y <= 0.0:
		if velocity.y < -6.0:
			_crash("CRASHED")
			return
		craft.position.y = 0.0
		velocity = Vector3(velocity.x * 0.5, maxf(velocity.y, 0.0), velocity.z * 0.5)
		on_ground = true
	elif craft.position.y > 0.3:
		if on_ground and started < 0.0:
			started = clock
		on_ground = false
	speed = velocity.length()


## Into what stands in its way: a building, a tree, a pylon.
func _hits(before: Vector3) -> void:
	var up := Vector3.UP * 1.2
	var hit := craft.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(before + up, craft.position + up))
	if hit and hit["position"].y > 0.3:  # not the ground's tiles
		_crash("CRASHED")


func _crash(why: String) -> void:
	crashed = 2.5
	_say_out(why + "\nback to the runway", 2.5)


## The next gate passed: across its line, between its pylons, under their tops.
func _gates(before: Vector3) -> void:
	if gate >= gates.size():
		return
	var g: Dictionary = gates[gate]
	var a: float = (before - g["at"]).dot(g["along"])
	var b: float = (craft.position - g["at"]).dot(g["along"])
	if a < 0.0 and b >= 0.0:
		var side: Vector3 = (craft.position - g["at"]) - g["along"] * b
		side.y = 0.0
		if side.length() < GATE_WIDTH / 2.0 and craft.position.y < GATE_TOP:
			gate += 1
			if gate == gates.size():
				finished = clock - started
				best = minf(best, finished)
				_say_out("COURSE %s\nnow land on the runway" % _time(finished), 4.0)
			else:
				_say_out("GATE %d" % gate, 1.0)
			_ring()


func _ring() -> void:
	ring.visible = gate < gates.size()
	if ring.visible:
		var g: Dictionary = gates[gate]
		ring.position = g["at"] + Vector3.UP * 10.0
		ring.basis = Basis.looking_at(g["along"], Vector3.UP) * Basis(Vector3.RIGHT, PI / 2)


## Traffic on its circle, banked into it, its propellers or rotors turning.
func _circle(t: Dictionary, delta: float) -> void:
	t["angle"] += t["speed"] / t["radius"] * delta
	var n: Node3D = t["node"]
	var c: Vector3 = t["centre"]
	var a: float = t["angle"]
	n.position = c + Vector3(cos(a), 0, sin(a)) * t["radius"]
	var along := Vector3(-sin(a), 0, cos(a))
	var bank := atan(t["speed"] * t["speed"] / (t["radius"] * G))
	var heli_bank := 0.4 if n.get_meta("prop")["name"].contains("heli") else 1.0
	n.basis = Basis.looking_at(-along, Vector3.UP) * Basis(Vector3.BACK, bank * heli_bank)  # into the turn, to its right
	_pose(n, {"spin": t["tracks"].get("spin", [])}, clock * 1.0)


## The course flown by itself: full throttle down the runway, off at the stall speed, gear up
## once climbing, steering for a point before the next gate then through it, at gate height near it.
func _autopilot() -> void:
	throttle = 1.0
	if gate >= gates.size():
		stick = Vector3.ZERO
		return
	var g: Dictionary = gates[gate]
	var to: Vector3 = g["at"] - craft.position
	to.y = 0.0
	var aim: Vector3 = g["at"] - g["along"] * clampf(to.length() - 60.0, 0.0, 120.0)
	var want := aim - craft.position
	var fwd := craft.basis.z
	var heading_error := Vector2(fwd.x, fwd.z).angle_to(Vector2(want.x, want.z))  # + to the right
	var height := 10.0 if to.length() < 260.0 else 40.0
	if heli:
		throttle = clampf((height - craft.position.y) * 0.5, -5.0, 5.0)
		stick = Vector3(clampf(-0.02 * want.length(), -0.8, 0.0), 0.0, clampf(heading_error * 2.0, -1.0, 1.0))
		return
	var climb := fwd.y * speed - sink
	var bank := asin(clampf(craft.basis.x.y, -1.0, 1.0))
	var want_bank := clampf(heading_error * 1.5, -0.9, 0.9) if craft.position.y > 6.0 else 0.0
	stick.y = clampf((want_bank - bank) * 2.0, -1.0, 1.0)
	stick.x = clampf((height - craft.position.y) * 0.03 - climb * 0.1, -0.6, 0.6)
	if fwd.y > 0.3 or fwd.y < -0.25:  # not too steep up or down
		stick.x = minf(stick.x, 0.0) if fwd.y > 0.3 else maxf(stick.x, 0.0)
	stick.z = 0.0
	if on_ground:
		stick.x = 1.0 if speed > hand[0] else 0.0
	if craft.position.y > 15.0:
		gear_up = true


func _process(delta: float) -> void:
	if not flying:
		super._process(delta)
		if walker:
			cam.far = 2000.0  # the field is wide
		return
	var size: Vector3 = abs(_gd(craft_prop["size"]))
	var length := maxf(size.z, size.x)
	var flat := Vector3(craft.basis.z.x, 0, craft.basis.z.z).normalized()
	var want := craft.position - flat * (length * 1.1 + 6.0) + Vector3.UP * (length * 0.3 + 2.5)
	cam.position = cam.position.lerp(want, 1.0 - exp(-delta * 5.0))
	cam.look_at(craft.position + Vector3.UP * size.y * 0.5 + flat * 4.0)
	cam.near = 0.1
	cam.far = 3000.0
	var gear_text := "" if not tracks.has("gear") else ("   GEAR UP" if gear_up else "   GEAR DOWN")
	var power := "ROTOR %d%%" % roundi(rotor * 100.0) if heli else ("GLIDING" if hand[2] == 0.0 else "THROTTLE %d%%" % roundi(throttle * 100.0))
	var course := "GATE %d/%d" % [mini(gate + 1, gates.size()), gates.size()] if gate < gates.size() else "COURSE DONE"
	board.text = "%s\n%d km/h   ALT %d m   %s%s\n%s   TIME %s   BEST %s" % [craft_prop["title"].to_upper(), speed * 3.6,
			craft.position.y, power, gear_text, course, _time((finished if finished > 0.0 else clock - started) if started >= 0.0 else 0.0), _time(best)]


func _say_out(text: String, seconds: float) -> void:
	call_out.text = text
	var t := get_tree().create_timer(seconds)
	t.timeout.connect(func():
		if call_out.text == text:
			call_out.text = "")


func _time(s: float) -> String:
	if s <= 0.0 or s == INF:
		return "-:--.--"
	return "%d:%05.2f" % [floori(s / 60.0), fmod(s, 60.0)]


func _unhandled_input(event: InputEvent) -> void:
	if flying:
		if event is InputEventKey and event.pressed and not event.echo:
			match event.keycode:
				KEY_ESCAPE:
					fly(false)
				KEY_R:
					_board(craft_index)
				KEY_C:
					_board(craft_index + 1)
				KEY_G:
					gear_up = not gear_up and not on_ground
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F and not walker:
		fly(true)
		return
	super._unhandled_input(event)
